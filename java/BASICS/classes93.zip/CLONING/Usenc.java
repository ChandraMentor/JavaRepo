/* shows some details about cloning
Author : Team - J 
Version: 1.0*/

import java.util.*;

class Usenc{
	public static void main(String a[]){
		nocloning n = new nocloning();
		n.set(10,10);
		nocloning n1 = n.cloneme();
	}
}
 