/* shows how to use vector
Author : Team - J 
Version: 1.0*/

import java.util.*;

class UseVect{
	public static void main(String args[]){
	Vector v = new Vector();
	v.addElement(new String("one")); // we can add any java object to vector
	v.addElement(new String("two"));
	v.addElement(new String("three"));
	v.addElement(new String("four"));
// let us use enumerator here
	Enumeration  e = v.elements(); // returns an enumeration object which can
					  // be used to iterate thr'u list.
	System.out.println(e);
	while (e.hasMoreElements())
		System.out.println(e.nextElement());

	}
}
 