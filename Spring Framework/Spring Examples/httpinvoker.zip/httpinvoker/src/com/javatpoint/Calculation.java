package com.javatpoint;

public interface Calculation {
int cube(int number);
}
