package com.javatpoint;

public class CalculationImpl implements Calculation{

	public int cube(int number) {
		return number*number*number;
	}

}
